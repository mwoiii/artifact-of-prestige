## 1.2.1

- Fixed symbols not being removed after TP is finished charging

## 1.2.0

- Mountain shrine symbols now stack on top of each other with the artifact active
  - Like in Returns also!!!
  - You can't turn this off! Next update...

## 1.1.0

- Mountain shrine symbol is now pink when the artifact is active
  - Like in Returns!!

## 1.0.0

- Implemented Artifact of Prestige
  - When active, attempts to spawn a Shrine of the Mountain at the start of a valid stage & carries over effects between stages
