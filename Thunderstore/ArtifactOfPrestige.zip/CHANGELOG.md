## 1.1.0

- Mountain shrine symbol is now pink when the artifact is active, like in Returns

## 1.0.0

- Implemented Artifact of Prestige
  - When active, attempts to spawn a Shrine of the Mountain at the start of a valid stage & carries over effects between stages
