# Artifact of Prestige

Implements the Artifact of Prestige as it appears in Risk of Rain Returns. Every stage, at least one Shrine of the Mountain will spawn, and effects of activated shrines are permanent for the run. Shrine of the Mountain symbols are pink, and, as a fun extra, Shrine of the Mountain symbols stack above each other on the teleporter while the artifact is active. This will be configurable next update.

The artifact is unlocked by default.