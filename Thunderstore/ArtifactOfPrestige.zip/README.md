# Artifact of Prestige

Implements the Artifact of Prestige as it appears in Risk of Rain Returns. Every stage, at least one Shrine of the Mountain will spawn, and effects of activated shrines are permanent for the run. This means that while teleporter bosses may be tougher, they also drop more items.

The artifact is unlocked by default.