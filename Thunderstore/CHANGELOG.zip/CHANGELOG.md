## 1.3.4
- README changes

## 1.3.3
- Fixed stacking icons not networking properly

## 1.3.2
- With the artifact active, mountain shrines can now be activated after the teleporter has started
  - Effects will take place next stage
  - Credit to kazucroco for the initial PR

## 1.3.1
- Fixed mod breaking game without ProperSave

## 1.3.0
- Added support for ProperSave

## 1.2.6

- Fixed an issue where the stacking indicator outside prestige setting was not working properly
- Updated mod icon

## 1.2.5

- Renamed asset bundle to reduce chance of mod conflicts

## 1.2.4

- Fixed extra items not working?? Was it even broken??
- Updated dependency string

## 1.2.3

- Fixed the symbol stacking option behaving exactly the same as the artifact & carrying between stages

## 1.2.2

- Added BepInEx config for:
  - Shrine symbol stacking
  - Shrine symbol colours
  - Enabling symbol stacking in regular runs
  - Enabling different shrine symbol colours in regular runs

- Config supports Risk of Options

## 1.2.1

- Fixed symbols not being removed after TP is finished charging

## 1.2.0

- Mountain shrine symbols now stack on top of each other with the artifact active
  - Like in Returns also!!!
  - You can't turn this off! Next update...

## 1.1.0

- Mountain shrine symbol is now pink when the artifact is active
  - Like in Returns!!

## 1.0.0

- Implemented Artifact of Prestige
  - When active, attempts to spawn a Shrine of the Mountain at the start of a valid stage & carries over effects between stages
